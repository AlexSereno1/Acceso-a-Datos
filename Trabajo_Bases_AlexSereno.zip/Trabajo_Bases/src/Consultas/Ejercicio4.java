
package Consultas;

/**
 *
 * @author Alex
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Ejercicio4 
{
    public static void main(String[] args) 
    {
      
        String url = "jdbc:mariadb://localhost:3307/trabajodb";
        String usuario = "root";
        String contraseña = "manager";

        try 
        {
           
            Class.forName("org.mariadb.jdbc.Driver");

           
            Connection conexion = DriverManager.getConnection(url, usuario, contraseña);

           
            String sql = "SELECT T.EXTEL, COUNT(T.NUMEM) AS NumEmpleados " +
                         "FROM TDEPTO D, TEMPLE T " +
                         "WHERE D.NUMDE = T.NUMDE AND D.PRESU > 100000 " +
                         "GROUP BY D.NUMDE, T.EXTEL";

           
            PreparedStatement statement = conexion.prepareStatement(sql);

  
            ResultSet resultado = statement.executeQuery();

           
            while (resultado.next()) 
            {
               
                int extel = resultado.getInt("EXTEL");
                int numEmpleados = resultado.getInt("NumEmpleados");

                
                System.out.println("Extel: " + extel + ", Número de empleados: " + numEmpleados);
            }

          
            resultado.close();
            statement.close();
            conexion.close();

        } 
        catch (ClassNotFoundException e) 
        {
            System.err.println("Error al cargar el controlador JDBC");
            e.printStackTrace();
        } 
        catch (SQLException e) 
        {
            System.err.println("Error de SQL");
            e.printStackTrace();
        }
    }
}