
package Ej8;

/**
 *
 * @author Clase
 */
import java.io.*;
import java.util.ArrayList;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import org.w3c.dom.*;

public class Ej8_3 
{
    public static void main(String[] args) 
    {
        int codigo;
        String nombre,direccion;
        float salario,comision;
        try 
        {
            // Abre el archivo de empleados.dat para lectura
            RandomAccessFile datFile = new RandomAccessFile("C:\\CarpetaAD\\empleados.dat", "r");

            // Crea un documento DOM
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.newDocument();

            // Crea el elemento raíz del documento XML
            Element rootElement = doc.createElement("empleados");
            doc.appendChild(rootElement);

            // Lee los datos del archivo empleados.dat
            try
            {
                while (datFile.getFilePointer() < datFile.length()) 
                {
                codigo = datFile.readInt();
                nombre = datFile.readUTF();
                direccion = datFile.readUTF();
                salario = datFile.readFloat();
                comision  = datFile.readFloat();

                // Crea un elemento de empleado y agrega sus atributos
                Element empleadoElement = doc.createElement("empleado");
                empleadoElement.setAttribute("codigo", String.valueOf(codigo));
                empleadoElement.setAttribute("nombre", nombre);
                empleadoElement.setAttribute("direccion", direccion);
                empleadoElement.setAttribute("salario", String.valueOf(salario));
                empleadoElement.setAttribute("comision", String.valueOf(comision));

                // Agrega el elemento de empleado al elemento raíz
                rootElement.appendChild(empleadoElement);
                }//fin bucle while
            }//fin try1
            catch(EOFException e)
            {
                System.out.println("Archivo acabado");
                System.out.println(" ");
            }//Fin catch2
            // Guarda el documento XML en el archivo
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");

            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File("C:\\CarpetaAD\\empleados.xml"));
            transformer.transform(source, result);

            System.out.println("Archivo XML creado correctamente: ");

            datFile.close();
        }//Fin try1 
        catch (Exception e ) 
        {
            e.printStackTrace();
        }//Fin catch1
    }//Fin main
}//Fin clase