
package Ej1;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.query.Query;
import java.io.File;

/**
 *
 * @author Clase
 */
public class VisualizarPruebasoft 
{
    public static void main(String args[])
    {
        Empresa e;
        Query con;
        ObjectSet res;
        File fichero=new File("BDJefeHijoEmp");
        fichero.delete();

        ObjectContainer baseDatos =Db4oEmbedded.openFile("BDJefeHijoEmp");

        Jefe lista1[]=new Jefe[3];

        lista1[0]=new Jefe("Nieves", 5,63,new Hijo("Vanesa", 27));
        lista1[1]=new Jefe("Elena", 1,42,new Hijo("David", 11));
        lista1[2]=new Jefe("Miguel", 20,45,new Hijo("Paula", 3));
        baseDatos.store(new Empresa("DesaSoft", lista1));

        Jefe lista2[]=new Jefe[2];

        lista2[0]=new Jefe("Vicki", 19, 44,new Hijo("Cristina", 12));
        lista2[1]=new Jefe("Dani", 3, 5,null); 

        baseDatos.store(new Empresa("PruebaSoft", lista2));

        con= baseDatos.query();
        con.constrain(Empresa.class);
        con.descend("nomEmpresa").constrain("PruebaSoft");
        res=con.execute();
        while(res.hasNext())
        {
            e=(Empresa) 
            res.next();
            e.visualInforEmpresa();
        }
        baseDatos.close();
    } 
}
