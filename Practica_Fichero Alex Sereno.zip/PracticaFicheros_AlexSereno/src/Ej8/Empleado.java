
package Ej8;

import java.io.Serializable;

/**
 *
 * @author Clase
 */
public class Empleado  implements Serializable
{
    private int codemp=0;
    private String nomemp="";
    private String diremp="";
    private float salemp=0;
    private float commemp=0;

    public Empleado(int codemp, String nomemp, String diremp, float salemp, float commemp) {
        this.codemp = codemp;
        this.nomemp = nomemp;
        this.diremp = diremp;
        this.salemp = salemp;
        this.commemp = commemp;
    }

    public int getCodemp() {
        return codemp;
    }

    public String getNomemp() {
        return nomemp;
    }

    public String getDiremp() {
        return diremp;
    }

    public float getSalemp() {
        return salemp;
    }

    public float getCommemp() {
        return commemp;
    }
    
    
}
