
package Ej8;

/**
 *
 * @author Clase
 */
import java.io.*;

public class Ej8_1 
{
    public static void main(String[] args) 
    {
        File f1=new File("C:\\CarpetaAD\\empleados.dat");
        try
        {
            // Definir los datos de cinco empleados
            FileOutputStream fileOut = new FileOutputStream(f1);
            DataOutputStream dataOut = new DataOutputStream(fileOut);
            
            int[] codigos = {1, 2, 3, 4, 5};
            String[] nombres = {"Juan", "Lucas ", "Laura", "Martina", "Luis "};
            String[] direcciones = {"C/ Luna", "C/ Desengaño", "C/ Mariposa", "C/ Leon", "C/ Sol"};
            float[] salarios = {2100.30f, 1345.23f, 1500.80f, 2700.0f, 2300.14f};
            float[] comisiones = {75.70f, 120.15f,100.0f, 110.0f, 150.0f};

            // Escribir los datos de los empleados en el archivo
            for (int i = 0; i < 5; i++) 
            {
                dataOut.writeInt(codigos[i]);
                dataOut.writeUTF(nombres[i]);
                dataOut.writeUTF(direcciones[i]);
                dataOut.writeFloat(salarios[i]);
                dataOut.writeFloat(comisiones[i]);
            }//Fin for

            System.out.println("Datos introducidos");
        }//Fin try
        catch (IOException e) 
        {
            System.out.println("ERROR");
        }//Fin catch
    }//Fin main
}//Fin clase
