
package Conexion_BaseX;

/**
 *
 * @author Alex
 */
import org.basex.api.client.ClientSession;

public class Conexion 
{
    public static void main(String[] args) 
    {
       //Es necesario inicar el servidor antes de ejecutar el programa
        String host = "localhost";
        int port = 1984;
        String username = "admin";
        String password = "manager";

       
        try (ClientSession session = new ClientSession(host, port, username, password)) 
        {
            
            String dbName = "biblioteca";
            session.execute("OPEN " + dbName);

            
            String query = "FIND //libro[autor = 'Mario Vargas Llosa']/titulo";
            String result = session.execute(query);

            
            System.out.println("Títulos de libros escritos por Mario Vargas Llosa:\n" + result);

        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
    }
}
