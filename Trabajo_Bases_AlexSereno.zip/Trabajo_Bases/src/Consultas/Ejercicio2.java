
package Consultas;

/**
 *
 * @author Alex
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Ejercicio2 
{
    public static void main(String[] args) 
    {
        
        String url = "jdbc:mariadb://localhost:3307/trabajodb";
        String usuario = "root";
        String contraseña = "manager";

        try 
        {
          
            Class.forName("org.mariadb.jdbc.Driver");

         
            Connection conexion = DriverManager.getConnection(url, usuario, contraseña);

          
            String sql = "SELECT NOMEM, SALAR FROM TEMPLE WHERE SALAR IN (SELECT COMIS FROM TEMPLE WHERE NUMEM = TEMPLE.NUMEM) ORDER BY NOMEM;";

            
            PreparedStatement statement = conexion.prepareStatement(sql);

            
            ResultSet resultado = statement.executeQuery();

           
            while (resultado.next()) 
            {
               
                String nombreEmpleado = resultado.getString("NOMEM");
                double salarioEmpleado = resultado.getDouble("SALAR");

              
                System.out.println("Nombre: " + nombreEmpleado + ", Salario: " + salarioEmpleado);
            }//fin while

           
            resultado.close();
            statement.close();
            conexion.close();

        }//Fin try
        catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }//Fin catch
    }//Fin main
}//Fin class