
package Consultas;

/**
 *
 * @author Alex
 */
import java.sql.*;

public class Ejercicio7 
{
    public static void main(String[] args) 
    {
        Connection conexion = null;
        CallableStatement cstmt = null;
        ResultSet rs = null;

        String url = "jdbc:mariadb://localhost:3307/trabajodb";
        String usuario = "root";
        String contraseña = "manager";

        try 
        {
            
            conexion = DriverManager.getConnection(url, usuario, contraseña);

          
            cstmt = conexion.prepareCall("{call MostrarEmpleadosConComisionNula()}");

            
            boolean tieneResultados = cstmt.execute();

           
            if (tieneResultados) 
            {
                
                rs = cstmt.getResultSet();
                
                System.out.println("Códigos de empleados con comisión nula:");
                while (rs.next()) 
                {
                    int numEm = rs.getInt("NUMEM");
                    String nomEm = rs.getString("NOMEM");
                    System.out.println("Número de empleado: " + numEm + ", Nombre: " + nomEm);
                }

                
                cstmt.getMoreResults();
                rs = cstmt.getResultSet();
                
                if (rs.next())
                {
                    int totalEmpleados = rs.getInt("TotalEmpleadosConComisionNula");
                    System.out.println("Total de empleados con comisión nula: " + totalEmpleados);
                }
            }
            rs.close();
            cstmt.close();
            conexion.close();
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        } 
    }
}