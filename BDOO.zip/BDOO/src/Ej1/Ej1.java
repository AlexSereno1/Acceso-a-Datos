package Ej1;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.query.Query;


/**
 *
 * @author Clase
 */
public class Ej1 
{
    /*
    En todos estos ejercicios trabajaremos con la misma base de datos “BDJefeHijoEmp” que se utilizó para los dos últimos ejemplos.

1.	Escribe un programa que muestre los datos de las empresas donde haya algún empleado que se llame “Gustavo”.


    */
    
    public static void main(String[] args) 
    {
        Empresa e;
        Query con1;
        ObjectSet res;
    
        ObjectContainer baseDatos =Db4oEmbedded.openFile("BDJefeHijoEmp");
        con1= baseDatos.query();
        con1.constrain(Empresa.class);
        con1.descend("lisJefes").descend("nombre").constrain("Gustavo");
        res=con1.execute();
        
        while(res.hasNext())
        {
            e=(Empresa)res.next();
            e.visualInforEmpresa();
        }
        baseDatos.close();
    }
}
