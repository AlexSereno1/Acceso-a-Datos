package Ej2;

import java.io.*;
import java.util.Scanner;

public class Ej2 {

    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);
        String ruta,texto;
        System.out.print("Introduce la ruta: ");
        ruta = scanner.next();

        System.out.print("Introduce el contenido del archivo: ");
        texto = scanner.next();
        
        File f1 =  new File(ruta);
        
        Escribir(f1, texto);
        Minusculas(f1);
    }
    //----------------------------------------------------
    public static void Escribir(File f1, String texto) 
    {
        try 
        {
            FileWriter fw = new FileWriter(f1);
            fw.write(texto);
            fw.close();
        }//Final try
        catch (IOException e) 
        {
            System.err.println("ERROR");
        }//Final catch
    }//Final metodo
    //---------------------------------------------------------
    public static void Minusculas(File f1) 
    {
        try 
        {
            FileReader fr = new FileReader(f1);
            int character;
            char c;
            while ((character = fr.read()) != -1) 
            {
                c = (char) character;
                System.out.print(Character.toLowerCase(c));
            }
            System.out.println(" ");
            fr.close();
        }//final try
        catch (IOException e) 
        {
            System.err.println("ERROR");
        }//Final catch
    }//Final metodo
}//Final Clase