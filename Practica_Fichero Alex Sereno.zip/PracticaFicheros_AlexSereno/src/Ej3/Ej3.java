package Ej3;

import java.io.*;
import java.util.Scanner;

public class Ej3 {
    public static void main(String[] args) 
    {
        Scanner entrada = new Scanner(System.in);
        String ruta1,ruta2,ruta3,rutaFinal;
        String nombre1,nombre2;
        System.out.println("Introduce la ruta del primer archivo de texto:");
        ruta1 = entrada.next();
        
        File f1=new File(ruta1);
        
        System.out.println("Introduce la ruta del segundo archivo de texto:");
        ruta2 = entrada.next();
        
        File f2=new File(ruta2);
         
        System.out.println("Introduce la ruta de destino (sin nombre de archivo al final):");
        ruta3 = entrada.next();
        
       
         
        nombre1 = f1.getName();
        nombre2 = f2.getName();

        
        rutaFinal= ruta3+ nombre1 + "_" + nombre2;
       
        File f3 = new File(rutaFinal);
        
        Copiado(f1,f2,f3);
        
    }//Final main
    //--------------------------------
    public static void Copiado(File f1,File f2,File f3)
    {
        Scanner entrada2 = new Scanner(System.in);

        if (f3.exists()) 
        {
            System.out.println("El archivo de destino ya existe.¿Quieres sobreescribirlo?(S/N)");
            String respuesta = entrada2.next();
            if (!respuesta.equalsIgnoreCase("S")) 
            {
                System.out.println("Operación cancelada.");
                return;
            }
        }

        try  
        {
            InputStream IS1 = new FileInputStream(f1);
            InputStream IS2 = new FileInputStream(f2);
            OutputStream OU = new FileOutputStream(f3);
            
            byte[] buffer = new byte[1024];
            int acum;
            
            while ((acum= IS1.read(buffer)) != -1) 
            {
                OU.write(buffer, 0, acum);
            }//Final bucle
            
            while ((acum = IS2.read(buffer)) != -1) 
            {
                OU.write(buffer, 0, acum);
            }//Final try
            
            System.out.println("Accion completada");
        }//Final try
        catch (IOException e) 
        {
            System.out.println("ERROR");
        }//Final catch
    }//Final metodo
}//Final Clase