
package Conexion_Mongo;

/**
 *
 * @author Alex
 */
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCursor;
import org.bson.Document;

public class Conexion_Mongo 
{
    public static void main(String[] args) 
    {
       
        try (MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017"))
        {
           
            MongoDatabase database = mongoClient.getDatabase("MiBaseDeDatos");
            MongoCollection<Document> collection = database.getCollection("alumnos");

            
            FindIterable<Document> documents = collection.find();
            MongoCursor<Document> cursor = documents.iterator();

          
            while (cursor.hasNext()) 
            {
                Document document = cursor.next();
                System.out.println(document.toJson());
            }
        }
    }
}