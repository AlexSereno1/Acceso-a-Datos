/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ej1;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.query.Query;

/**
 *
 * @author Clase
 */
public class Ej2 
{
    /*
    2.	Escribe un programa que muestre la información de las empresas donde alguno de sus jefes tenga algún hijo mayor de 18 años.



    */
    
    public static void main(String[] args) 
    {
        Empresa e;
        Query con1;
        ObjectSet res;
    
        ObjectContainer baseDatos =Db4oEmbedded.openFile("BDJefeHijoEmp");
        con1= baseDatos.query();
        con1.constrain(Empresa.class);
        con1.descend("lisJefes").descend("inforUnHijo").descend("edad").constrain(18).greater();
        res=con1.execute();
        
        while(res.hasNext())
        {
            e=(Empresa)
            res.next
            ();
            e.visualInforEmpresa();
        }
        baseDatos.close();
    }
}
