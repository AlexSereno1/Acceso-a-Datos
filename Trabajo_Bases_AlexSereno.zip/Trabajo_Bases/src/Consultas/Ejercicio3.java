
package Consultas;

/**
 *
 * @author Clase
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Ejercicio3 
{
    public static void main(String[] args) 
    {
       
        String url = "jdbc:mariadb://localhost:3307/trabajodb";
        String usuario = "root";
        String contraseña = "manager";

        try {
         
            Class.forName("org.mariadb.jdbc.Driver");

      
            Connection conexion = DriverManager.getConnection(url, usuario, contraseña);

          
            String sql = "SELECT COUNT(*) NumEmpleados ,SUM(E.SALAR) SumaSalarios,SUM(NVL(E.COMIS, 0)) "
                    + "SumaComisiones, SUM(E.NUMHI) SumaNumHijos FROM TEMPLE E, TDEPTO D WHERE E.NUMDE = D.NUMDE AND D.TIDIR = 'F';";

            
            PreparedStatement statement = conexion.prepareStatement(sql);

           
            ResultSet resultado = statement.executeQuery();

         
            if (resultado.next()) 
            {
              
                int numEmpleados = resultado.getInt("NumEmpleados");
                double sumaSalarios = resultado.getDouble("SumaSalarios");
                double sumaComisiones = resultado.getDouble("SumaComisiones");
                int sumaNumHijos = resultado.getInt("SumaNumHijos");

             
                System.out.println("Número de empleados: " + numEmpleados);
                System.out.println("Suma total de salarios: " + sumaSalarios);
                System.out.println("Suma total de comisiones: " + sumaComisiones);
                System.out.println("Suma total de número de hijos: " + sumaNumHijos);
            }

          
            resultado.close();
            statement.close();
            conexion.close();

        } 
        catch (ClassNotFoundException | SQLException e) 
        {
            e.printStackTrace();
        }
    }
}