
package Ej1;

/**
 *
 * @author Clase
 */
public class Empresa
{
    String nomEmpresa;
    Jefe lisJefes[];

    Empresa(String n, Jefe lista[])
    {
        nomEmpresa=n;
        lisJefes=lista;
    }

    int devNumJefes()
    {
        return lisJefes.length;
    }

    void visualInforEmpresa()
    {
        System.out.println("\n\nEl nombre de la empresa es " + nomEmpresa);
        System.out.println("\n\nLa información de los jefes que tiene dicha empresa son: ");
        for(int pos=0;pos<lisJefes.length;pos++)
        {
            lisJefes[pos].visDatosJefe();
        }
    }
} 