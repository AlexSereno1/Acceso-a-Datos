
package Ej5;

import java.io.*;
import java.util.Scanner;

public class Ej5 
{
    public static void main(String[] args)
    {
        Scanner entrada = new Scanner(System.in);
        
        String matricula,marca,modelo;
        double deposito;
        
        String matricula2,marca2,modelo2;
        double deposito2;
        try 
        {
           
            File f1 = new File("C:\\CarpetaAD\\Fichero5.dat");
            FileOutputStream fileout = new FileOutputStream(f1);
            DataOutputStream dataout = new DataOutputStream(fileout);

           
            System.out.print("Introduce la matrícula del vehículo: ");
            matricula = entrada.next();
            
            System.out.print("Introduce la marca del vehículo: ");
            marca = entrada.next();
            
            System.out.print("Introduce el tamaño del depósito del vehículo: ");
            deposito = entrada.nextDouble();
            
            System.out.print("Introduce el modelo del vehículo: ");
            modelo = entrada.next();
            
            dataout.writeUTF(matricula);
            dataout.writeUTF(marca);
            dataout.writeDouble(deposito);
            dataout.writeUTF(modelo);

            dataout.close();
            fileout.close();

          
            FileInputStream filein = new FileInputStream(f1);
            DataInputStream datain = new DataInputStream(filein);

            System.out.println("Datos:");
            try 
            {
                while (true) 
                {
                    matricula2 = datain.readUTF();
                    marca2 = datain.readUTF();
                    deposito2 = datain.readDouble();
                    modelo2 = datain.readUTF();

                    System.out.println("Matrícula: " + matricula2);
                    System.out.println("Marca: " + marca2);
                    System.out.println("Tamaño del depósito: " + deposito2);
                    System.out.println("Modelo: " + modelo2);
                    System.out.println();
                }//Fin bucle while
            }//Fin try2 
            catch (EOFException e) 
            {
                System.out.println("Se han terminado el fichero");
                System.out.println(" ");
               
            }//Fin catch2
            datain.close();
            filein.close();
        }//Fin try1
        catch (IOException e) 
        {
            System.out.println("ERROR");
        }//Fin catch 1
    }//Fin main
}//Fin class