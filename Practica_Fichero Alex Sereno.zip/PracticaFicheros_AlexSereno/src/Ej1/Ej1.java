
package Ej1;

import java.io.*;

/**
 *
 * @author Alex
 */
public class Ej1
{
    public static void main(String[] args) throws FileNotFoundException 
    { 
        try 
        {
            File f1 = new File("C:\\CarpetaAD\\Fichero1.txt");
            FileReader fr = new FileReader(f1);
            int acum;
           
            while ((acum = fr.read()) != -1) 
            {
                if (acum != ' ') 
                    System.out.print((char)acum);
            }
            fr.close();
        } //Final try
        catch (IOException e) 
        {
            System.out.println("ERROR");
        }//Final catch
    }//Final main
}//Final clase
