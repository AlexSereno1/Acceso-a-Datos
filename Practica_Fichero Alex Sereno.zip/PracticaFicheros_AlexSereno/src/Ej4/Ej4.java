package Ej4;

import java.io.*;
import java.util.Scanner;

public class Ej4 
{
    public static void main(String[] args) 
    {
        int num,random,num2;
        String ruta;
        Scanner entrada = new Scanner(System.in);

        System.out.print("Introduce la cantidad de números aleatorios enteros positivos que deseas generar: ");
        num = entrada.nextInt();

        System.out.print("Introduce la ruta del fichero: ");
        ruta = entrada.next();
        
        File f1 = new File(ruta);
        try 
        {
            FileOutputStream fileout = new FileOutputStream(f1);
            DataOutputStream dataout = new DataOutputStream(fileout);

            for (int i = 0; i < num; i++) 
            {
                random =(int)(Math.random()*101);
                dataout.writeInt(random);
            }//Fin bucle for

            dataout.close();
            fileout.close();

            FileInputStream filein = new FileInputStream(f1);
            DataInputStream datain = new DataInputStream(filein);

            System.out.println("Números en el fichero:");

            try 
            {
                while (true) 
                {
                    num2 = datain.readInt();
                    System.out.print(num2 + " ");
                }//Fin bucle
            }//Fin try2 
            catch (EOFException e) 
            {
                System.out.println(" ");
                System.out.println("Se han terminado el fichero");
            }//Fin catch2
            datain.close();
            filein.close();

        } //Fin try1
        catch (IOException e) 
        {
            System.out.println("ERROR 2");
            
        }//Fin catch1
    }//Fin main
}//Fin clase