
package Ej9;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.*;
import org.xml.sax.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;

public class Ej9 
{
    public static void main(String[] args) 
    {
        String dni,nombre,apellido,dia,mes,annio,poblacion;
        try 
        {
            
            DocumentBuilderFactory builder = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = builder.newDocumentBuilder();
            Document document = documentBuilder.newDocument();

           
            Element raiz = document.createElement("contactos");
            document.appendChild(raiz);

            
            Element persona1 = crear(document, "434235", "Pepe", "Pinillos", "30", "3", "1976", "Avenida de la Felicidad", "34", "Villaarriba del Condado", "Libertonia");
            raiz.appendChild(persona1);

           
            Element persona2 = crear(document, "63463636", "Pepito", "Grillo", "12", "8", "1954", "Calle de las Flores", "25", "Villaarriba del Condado", "Libertonia");
            raiz.appendChild(persona2);

          
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            
            DOMSource source = new DOMSource(document);
            
            File f1=new File("C:\\CarpetaAD\\contactos.xml");
            StreamResult result = new StreamResult(f1);
            
            transformer.transform(source, result);

            System.out.println("Archivo XML 'contactos.xml' creado exitosamente.");

            
            Document xmlDoc = documentBuilder.parse(f1);
            xmlDoc.getDocumentElement().normalize();

            NodeList listaPersonas = xmlDoc.getElementsByTagName("persona");
            for (int i = 0; i < listaPersonas.getLength(); i++) 
            {
                Node personaNode = listaPersonas.item(i);
                
                if (personaNode.getNodeType() == Node.ELEMENT_NODE) 
                {
                    Element personaElement = (Element) personaNode;
                    dni = personaElement.getAttribute("dni");
                    nombre = personaElement.getElementsByTagName("nombre").item(0).getTextContent();
                    apellido = personaElement.getElementsByTagName("apellido").item(0).getTextContent();
                    dia = personaElement.getElementsByTagName("dia").item(0).getTextContent();
                    mes = personaElement.getElementsByTagName("mes").item(0).getTextContent();
                    annio = personaElement.getElementsByTagName("anio").item(0).getTextContent();
                    poblacion = personaElement.getElementsByTagName("poblacion").item(0).getTextContent();

                    System.out.println("DNI: " + dni);
                    System.out.println("Nombre: " + nombre);
                    System.out.println("Apellido: " + apellido);
                    System.out.println("Fecha de nacimiento: " + dia + " / " + mes + " / " + annio);
                    System.out.println("Población: " + poblacion);
                    System.out.println();
                }//Fin if
            }//Fin bucle for
        }//Fin try
        catch (Exception e) 
        {
            System.out.println("ERROR");
        }//Fin catch
    }//Fin main

    public static Element crear(Document doc, String dni, String nombre, String apellido, String diaNac, String mesNac, 
            String anioNac, String calle, String numero, String poblacion, String pais) 
    {
        Element persona = doc.createElement("persona");
        persona.setAttribute("dni", dni);

        Element nombreElement = doc.createElement("nombre");
        nombreElement.appendChild(doc.createTextNode(nombre));
        persona.appendChild(nombreElement);

        Element apellidoElement = doc.createElement("apellido");
        apellidoElement.appendChild(doc.createTextNode(apellido));
        persona.appendChild(apellidoElement);

        Element fechaNacimiento = doc.createElement("fechanacimiento");
        Element diaElement = doc.createElement("dia");
        diaElement.appendChild(doc.createTextNode(diaNac));
        fechaNacimiento.appendChild(diaElement);
        Element mesElement = doc.createElement("mes");
        mesElement.appendChild(doc.createTextNode(mesNac));
        fechaNacimiento.appendChild(mesElement);
        Element anioElement = doc.createElement("anio");
        anioElement.appendChild(doc.createTextNode(anioNac));
        fechaNacimiento.appendChild(anioElement);
        persona.appendChild(fechaNacimiento);

        Element direccion = doc.createElement("direccion");
        Element calleElement = doc.createElement("calle");
        calleElement.appendChild(doc.createTextNode(calle));
        direccion.appendChild(calleElement);
        Element numeroElement = doc.createElement("numero");
        numeroElement.appendChild(doc.createTextNode(numero));
        direccion.appendChild(numeroElement);
        Element poblacionElement = doc.createElement("poblacion");
        poblacionElement.appendChild(doc.createTextNode(poblacion));
        direccion.appendChild(poblacionElement);
        Element paisElement = doc.createElement("pais");
        paisElement.appendChild(doc.createTextNode(pais));
        direccion.appendChild(paisElement);
        persona.appendChild(direccion);

        return persona;
    }//Fin metodo
}//Fin clase