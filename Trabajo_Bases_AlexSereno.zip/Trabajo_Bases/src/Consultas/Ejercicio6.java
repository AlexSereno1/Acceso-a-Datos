
package Consultas;

/**
 *
 * @author Alex
 */
import java.sql.*;

public class Ejercicio6
{
    public static void main(String[] args) 
    {
       
        String url = "jdbc:mariadb://localhost:3307/trabajodb";
        String usuario = "root";
        String contraseña = "manager";

        try 
        {
           
            Class.forName("org.mariadb.jdbc.Driver");

            
            Connection conexion = DriverManager.getConnection(url, usuario, contraseña);
            int deptoId = 111;
            
            try (CallableStatement callableStatement = conexion.prepareCall("{call MostrarEmpleadosPorDepartamento(?)}")) 
            {
         
            callableStatement.setInt(1, deptoId);

          
            ResultSet resultSet = callableStatement.executeQuery();

            
            while (resultSet.next()) 
            {
                int numem = resultSet.getInt("NUMEM");
                String nomem = resultSet.getString("NOMEM");

               
                System.out.println("Número de empleado: " + numem + ", Nombre: " + nomem);
            }
        }
        catch(SQLException e)
        {
            System.out.println(e);
        }
            
        conexion.close();

        } catch (ClassNotFoundException e) 
        {
            System.err.println("Error al cargar el controlador JDBC");
            e.printStackTrace();
        } 
        catch (SQLException e) 
        {
            System.err.println("Error de SQL");
            e.printStackTrace();
        }
    }
}