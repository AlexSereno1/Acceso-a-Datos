/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ej1;

/**
 *
 * @author Clase
 */
public class Jefe {
    
    String nombre;
    int antiguedad;
    int edad;
    Hijo inforUnHijo;
    
    Jefe(String n, int ant, int e, Hijo h) {
        nombre=n;
        antiguedad=ant;
        edad=e;
        inforUnHijo=h;
    }
    
    void visDatosJefe() {
        System.out.println("\n"+nombre+ " tiene " +edad+ " años, lleva "+antiguedad+" años"
                + "\nen la empresa"); 
        if (inforUnHijo != null)
        {
            System.out.println("Los datos de su hijo son : ");
            inforUnHijo.visualHijo();
        }
        
    }
    
    void cumpleAños ()
    {
        edad++;
    }

   
    
}
