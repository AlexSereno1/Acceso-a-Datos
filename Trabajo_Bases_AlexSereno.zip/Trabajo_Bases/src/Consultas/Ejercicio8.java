
package Consultas;
/**
 *
 * @author Alex
 */
import java.sql.*;

public class Ejercicio8 
{
    public static void main(String[] args) 
    {
        String url = "jdbc:mariadb://localhost:3307/trabajodb";
        String usuario = "root";
        String contraseña = "manager";

        try 
        {
            Class.forName("org.mariadb.jdbc.Driver");
            Connection conexion = DriverManager.getConnection(url, usuario, contraseña);

            try (CallableStatement callableStatement = conexion.prepareCall("{call BuscarEmpleadosPorApellido(?)}")) 
            {
                callableStatement.setString(1, "PONS");

                boolean tieneResultados = callableStatement.execute();
                if (tieneResultados) 
                {
                    try (ResultSet resultSet = callableStatement.getResultSet()) 
                    {
                        while (resultSet.next()) 
                        {
                            int numem = resultSet.getInt("NUMEM");
                            String nomem = resultSet.getString("NOMEM");
                            System.out.println("Número de empleado: " + numem + ", Nombre: " + nomem);
                        }
                    }
                } 
                else 
                {
                    
                    System.out.println("No se encontraron empleados con el apellido proporcionado.");
                }
            }

            conexion.close();

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}