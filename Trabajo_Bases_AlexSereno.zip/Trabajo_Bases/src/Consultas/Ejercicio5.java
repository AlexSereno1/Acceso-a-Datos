
package Consultas;

/**
 *
 * @author Alex
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Ejercicio5 
{
    public static void main(String[] args) 
    {
       
        String url = "jdbc:mariadb://localhost:3307/trabajodb";
        String usuario = "root";
        String contraseña = "manager";

        try 
        {
            Class.forName("org.mariadb.jdbc.Driver");

            Connection conexion = DriverManager.getConnection(url, usuario, contraseña);

            Statement statement = conexion.createStatement();

            String sql = "UPDATE TEMPLE SET SALAR = SALAR * 1.0533, COMIS = IFNULL(COMIS, 0) * 1.0619";

            int filasActualizadas = statement.executeUpdate(sql);

            System.out.println("Se actualizaron " + filasActualizadas + " filas.");

            statement.close();
            conexion.close();

        } 
        catch (ClassNotFoundException e) 
        {
            System.err.println("Error al cargar el controlador JDBC");
            e.printStackTrace();
        } 
        catch (SQLException e) 
        {
            System.err.println("Error de SQL");
            e.printStackTrace();
        }
    }
}