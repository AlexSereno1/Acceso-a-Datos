package Consultas;
/**
 *
 * @author Alex
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;

public class Ejercicio1 
{
    public static void main(String[] args) 
    {
       
        String url = "jdbc:mariadb://localhost:3307/trabajodb";
        String usuario = "root";
        String contraseña = "manager";

        try 
        {
         
            Class.forName("org.mariadb.jdbc.Driver");

           
            Connection conexion = DriverManager.getConnection(url, usuario, contraseña);

            
            LocalDate fechaHoy = LocalDate.now();

            
            String sql = "SELECT AVG(DATEDIFF(?, FECIN) / 365) AS MediaAniosServicio " +
                         "FROM TEMPLE " +
                         "WHERE NUMDE IN (111, 112)";

           
            PreparedStatement statement = conexion.prepareStatement(sql);

            
            statement.setDate(1, java.sql.Date.valueOf(fechaHoy));

            
            ResultSet resultado = statement.executeQuery();

          
            if (resultado.next()) 
            {
               
                double mediaAniosServicio = resultado.getDouble("MediaAniosServicio");

                
                System.out.println("Media de años de servicio: " + mediaAniosServicio);
            }//Fin if

           
            resultado.close();
            statement.close();
            conexion.close();

        }//Fin try
        catch (ClassNotFoundException | SQLException e) 
        {
            e.printStackTrace();
        }//Fin catch
    }//Fin main
}//Fin class