
package Ej7;

/**
 *
 * @author Clase
 */
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Ej7 
{
    public static void main(String[] args) 
    {
        File f1=new File("C:\\CarpetaAD\\Fichero7.dat");
        ArrayList <Vehiculo> listaVehiculos = new ArrayList <Vehiculo>();
        try
        {
            
            Scanner entrada=new Scanner(System.in);
            
            String matricula,marca,modelo;
            double deposito;
            
           
            FileOutputStream fileOut =new FileOutputStream(f1);
            ObjectOutputStream objectOut=new ObjectOutputStream(fileOut);
         
           
            System.out.print("Introduce la matrícula del vehículo : ");
            matricula = entrada.next();
         
            System.out.print("Introduce la marca del vehículo: ");
            marca = entrada.next();

            System.out.print("Introduce el modelo del vehículo: ");
            modelo=entrada.next();
            
            System.out.print("Introduce el deposito del vehículo: ");
            deposito=entrada.nextDouble();

            Vehiculo vehiculo = new Vehiculo(matricula,marca,modelo,deposito);
            listaVehiculos.add(vehiculo);
            objectOut.writeObject(vehiculo);
            
        }//Fin try1
        catch(IOException e)
        {
            System.out.println("ERROR");
        }//Fin catch1

        try
        {
            FileInputStream fileIn =new FileInputStream(f1);
            ObjectInputStream objectIn = new ObjectInputStream(fileIn);
            
            System.out.println("Datos de los vehículos almacenados:");
            for (int i = 0; i < listaVehiculos.size();i++) 
            {
                System.out.println("Matricula: "+listaVehiculos.get(i).getMatricula());
                System.out.println("Marca: "+listaVehiculos.get(i).getMarca());
                System.out.println("Modelo: "+listaVehiculos.get(i).getModelo());
                System.out.println("Deposito: "+listaVehiculos.get(i).getDeposito());
            }//Fin for
        }//Fin try2
        catch (IOException e) 
        {
            System.out.println("ERROR");;
        }//Fin catch2
    }//Fin main
}//Fin clase
