
package Ej1;

/**
 *
 * @author Clase
 */

import com.db4o.*;
import com.db4o.query.Query;
import java.io.File;
public class Principal
{
public static void main(String args[])
{
    Hijo h;
    Jefe j;
    Query con;
    ObjectSet res;
    Empresa e;
    File fichero=new File("BDJefeHijoEmp");
    fichero.delete();

    ObjectContainer baseDatos =Db4oEmbedded.openFile("BDJefeHijoEmp");

    Jefe lista1[]=new Jefe[3];
    lista1[0]=new Jefe("Jesús", 5,63,new Hijo("Noelia", 27));
    lista1[1]=new Jefe("Elena", 1,42,new Hijo("David", 11));
    lista1[2]=new Jefe("Miguel", 20,45,new Hijo("Paula", 3));
    baseDatos.store (new Empresa("DesaSoft", lista1));

    Jefe lista2[]=new Jefe[2]; 
    lista2[0]=new Jefe("Ángel", 19, 44,new Hijo("Lara", 12));
    lista2[1]=new Jefe("Gustavo", 3, 5,null);   
    baseDatos.store (new Empresa("PruebaSoft", lista2));

    System.out.println("\n\nVAMOS A VISUALIZAR LA INFORMACIÓN DE LOS HIJOS QUE HAY EN LA BASE DE DATOS: ");
    /*Usamos la consulta por el API SODA*/
    con= baseDatos.query();
    con.constrain(Hijo.class);
    res=con.execute();
    while(res.hasNext())
    {
        h=(Hijo)
        res.next
        ();
        h.visualHijo();
    }

    System.out.println("\n\nVAMOS A VISUALIZAR LA INFORMACIÓN DE LOS JEFES QUE HAY EN LA BASE DE DATOS: ");
    /*Usamos la consulta por el QBE*/
    res= baseDatos.queryByExample(new Jefe(null,0,0,null));
    while(res.hasNext())
    {
        j=(Jefe)
        res.next
        ();
        j.visDatosJefe();
    }

    System.out.println("\n\nVAMOS A VISUALIZAR LA INFORMACIÓN DE TODAS LAS EMPRESAS QUE HAY EN LA BASE DE DATOS: ");
    /*Usamos la consulta por el QBE*/
    res= baseDatos.queryByExample(new Empresa(null,null));
    while(res.hasNext())
    {
        e=(Empresa)
        res.next
        ();
        e.visualInforEmpresa();
    }
    baseDatos.close();
    }
} 