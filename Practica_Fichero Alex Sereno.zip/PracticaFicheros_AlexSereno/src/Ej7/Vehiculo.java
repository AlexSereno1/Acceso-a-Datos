
package Ej7;

/**
 *
 * @author Clase
 */
import java.io.*;

public class Vehiculo implements Serializable
{
    private String matricula;
    private String marca;
    private double deposito;
    private String modelo;

    public Vehiculo(String matricula, String marca, String modelo,double deposito ) {
        this.matricula = matricula;
        this.marca = marca;
        this.modelo = modelo;
        this.deposito=deposito;
    }

    public String getMatricula() {
        return matricula;
    }

    public String getMarca() {
        return marca;
    }

    public double getDeposito() {
        return deposito;
    }

    public String getModelo() {
        return modelo;
    }

    @Override
    public String toString() {
        return "Matrícula: " + matricula + ", Marca: " + marca + ", Tamaño del depósito: " + deposito + ", Modelo: " + modelo;
    }
}
