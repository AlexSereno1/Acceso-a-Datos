
package Ej6;

import java.io.*;
import java.util.Scanner;

public class Ej6 
{
    public static void main(String[] args) 
    {
        File f1 = new File("C:\\CarpetaAD\\Fichero6.dat");
        Scanner entrada = new Scanner(System.in);
        int opcion;
        
        while (true) 
        {
            System.out.println("Menú:");
            System.out.println("--------------------------------");
            System.out.println("1. Añadir números de tipo double al principio del fichero.");
            System.out.println("2. Añadir números de tipo double al final del fichero.");
            System.out.println("3. Mostrar el fichero creado.");
            System.out.println("4. Sustituir un número en el fichero.");
            System.out.println("5. Salir");
            System.out.print("Elija una opción: ");

            opcion = entrada.nextInt();

            switch (opcion) 
            {
                case 1:
                    añadirAlPrincipio(f1);
                    break;
                case 2:
                    añadirAlFinal(f1);
                    break;
                case 3:
                    mostrarArchivo(f1);
                    break;
                case 4:
                    sustituirNumero(f1);
                    break;
                case 5:
                    System.out.println("Saliendo del programa.");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }//Final switch
        }//Fin bucle
    }//Fin main
    //------------------------------------------------------
    public static void añadirAlPrincipio(File f1)
    {
        try 
        {
            RandomAccessFile file = new RandomAccessFile(f1, "rw");
            double numero;
            Scanner entrada = new Scanner(System.in);
            
            System.out.print("Introduzca un  double para añadir al principio del fichero: ");
            numero = entrada.nextDouble();

            file.seek(0);
            file.writeDouble(numero);
            file.close();

            System.out.println("Número añadido al principio del fichero.");
        }//Final try
        catch (IOException e) 
        {
            System.out.println("ERROR");
        }//Final catch
    }//Final metodo
    //-------------------------------------------------
    public static void añadirAlFinal(File f1) 
    {
        try 
        {
            RandomAccessFile file = new RandomAccessFile(f1, "rw");
            double numero;
            long longitud;
            Scanner entrada = new Scanner(System.in);
             
            System.out.print("Introduzca un  double para añadir al final del fichero: ");
            numero = entrada.nextDouble();

            longitud = file.length();
            file.seek(longitud);
            file.writeDouble(numero);
            file.close();

            System.out.println("Número añadido al final del fichero.");
        } //Final try
        catch (IOException e) 
        {
            System.out.println("ERROR");
        }//Final catch
    }//Final metodo
    //---------------------------------------------
    public static void mostrarArchivo(File f1)
    {
        try 
        {
            RandomAccessFile file = new RandomAccessFile(f1, "r");
            System.out.println("Contenido del fichero:");
            double numero;
            
            while (file.getFilePointer() < file  .length()) 
            {
                numero = file.readDouble();
                System.out.println(numero);
            }//Final bucle
            file.close();
        }//Final try
        catch (IOException e) 
        {
            System.out.println("ERROR");
        }//Final catch
    }//Final metodo
    //--------------------------------------------------
    public static void sustituirNumero(File f1) 
    {
        try 
        {
            RandomAccessFile file = new RandomAccessFile(f1, "rw");
            Scanner entrada=new Scanner(System.in);
            int pos;
            double numero;
            System.out.print("Introduzca la posición del número que desea sustituir (La primera posicion es 0): ");
            pos = entrada.nextInt();

            if (pos < 0 || pos >= file.length() / 8) {
                System.out.println("Posición no válida.");
                file.close();
                return;
            }//Final if

            System.out.print("Introduzca el nuevo numero: ");
            numero =entrada.nextDouble();

            file.seek(pos * 8);
            file.writeDouble(numero);
            file.close();

            System.out.println("Número sustituido");
        }//Final try
        catch (IOException e) 
        {
            System.out.println("ERROR");
        }//Final catch
    }//Final metodo
}//Final class