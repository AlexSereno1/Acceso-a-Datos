/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ej8;


import javax.xml.parsers.*;
import org.w3c.dom.*;
import java.io.*;

public class Ej8_4 {
    public static void main(String[] args) 
    {
        String codigo,nombre,direccion,salario,comision;
        try {
            // Crear un objeto DocumentBuilderFactory para crear un analizador DOM
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();

            // Cargar el archivo XML
            File f1 = new File("C:\\CarpetaAD\\empleados.xml");
            Document document = builder.parse(f1);

            // Obtener el elemento raíz
            Element root = document.getDocumentElement();

            // Obtener todos los elementos 'empleado'
            NodeList empleados = root.getElementsByTagName("empleado");

            // Recorrer la lista de empleados y mostrar su información
            for (int i = 0; i < empleados.getLength(); i++)
            {
                Element empleado = (Element) empleados.item(i);
                codigo = empleado.getAttribute("codigo");
                nombre = empleado.getAttribute("nombre");
                direccion = empleado.getAttribute("direccion");
                salario = empleado.getAttribute("salario");
                comision = empleado.getAttribute("comision");

                System.out.println("Empleado: " + (i + 1));
                System.out.println("Código: " + codigo);
                System.out.println("Nombre: " + nombre);
                System.out.println("Dirección: " + direccion);
                System.out.println("Salario: " + salario);
                System.out.println("Comisión: " + comision);
                System.out.println();
            }//fin bucle for
        }//Fin try
        catch (Exception e) 
        {
            System.out.println("ERROR");
        }//Fin catch
    }//Fin main
}//Fin clase
