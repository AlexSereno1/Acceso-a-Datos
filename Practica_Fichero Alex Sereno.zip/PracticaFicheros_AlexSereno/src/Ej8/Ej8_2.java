
package Ej8;

/**
 *
 * @author Clase
 */



public class Ej8_2 
{
    public static void main(String[] args) 
    {
        
    }
}
