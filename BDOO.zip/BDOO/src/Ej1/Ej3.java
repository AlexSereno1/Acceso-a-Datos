package Ej1;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.query.Query;

/**
 *
 * @author Clase
 */
public class Ej3 
{
    /*
        3.	Escribe un programa que muestre la información de las empresas donde haya algún jefe que no tenga hijos. 
    */
    public static void main(String[] args) 
    {
        Empresa e;
        Query con1;
        ObjectSet res;
    
        ObjectContainer baseDatos =Db4oEmbedded.openFile("BDJefeHijoEmp");
        con1= baseDatos.query();
        con1.constrain(Empresa.class);
        con1.descend("lisJefes").descend("inforUnHijo").constrain(null);
        res=con1.execute();
        
        while(res.hasNext())
        {
            e=(Empresa)
            res.next
            ();
            e.visualInforEmpresa();
        }
        baseDatos.close();
    }
}
